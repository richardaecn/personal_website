Cornell Recipe9K dataset

Last modified: 12/11/2015

FAIR USE STATEMENT:This dataset contains copyrighted material under the educational fair use exemption to the U.S. copyright law.

Distributed together with:

PlateClick: Bootstrapping Food Preferences Through an Adaptive Visual Interface.
Longqi Yang, Yin Cui, Fan Zhang, John P. Pollak, Serge Belongie, Deborah Estrin
International Conference on Information and Knowledge Management (CIKM), 2015 ACM

If you use this dataset, please cite:

@inproceedings{YangCZPBE15,
title = {PlateClick: Bootstrapping Food Preferences Through an Adaptive Visual Interface},
author = {Longqi Yang and Yin Cui and Fan Zhang and John P. Pollak and Serge Belongie and Deborah Estrin},
year = {2015},
booktitle = {International Conference on Information and Knowledge Management (CIKM)},
organization = {ACM}
}

File descriptions:

* Dataset URL: http://www.cs.cornell.edu/~ylongqi/data/recipe9k.zip

* recipe9k.json:
  A list of 9,404 recipes collected from Yummly. It contains the following keys:
  	
  	"id": Yummly recipe ID, which can be used to collect detailed metadata via Yummly API (https://developer.yummly.com/).
  	"url": Food image URL.

Data collection details:

We pulled the main dishes recipes via Yummly API and filtered out entries with unrelated (or missing) image content. These are part of the data engine that drives PlateClick (http://bit.ly/plateclick).

Please email any question to: ylongqi@cs.cornell.edu